import lt.itakademija.exam.IntegerGenerator;

public class MyIntegerGenerator implements IntegerGenerator {
    @Override
    public Integer getNext() {
        return null;
    }
}
